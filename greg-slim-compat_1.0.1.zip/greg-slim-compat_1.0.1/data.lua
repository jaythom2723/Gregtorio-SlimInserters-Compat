greg_slim_compat = greg_slim_compat or {}

require("util")
